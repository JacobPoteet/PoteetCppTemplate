//Jacob Poteet
//2020
//Austin, TX
#include "Main.h"


int main() {

    //mainFile.open(FileToSearch);
    //mainFile.close();



    PauseCommandPrompt();
    return 0;
}



void PrintString(string message) {

    cout << message << endl;

    return;
}