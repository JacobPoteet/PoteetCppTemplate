//Jacob Poteet

#pragma once
#include <iostream>
#include <vector>
#include <string>
//#include <fstream>

using namespace std;



/*-----------------------------------*/
/*Global Variable*/
/*-----------------------------------*/

//string FileToSearch = "MainDoc.txt";
//ifstream mainFile;

/*-----------------------------------*/




/*-----------------------------------*/
/*Functions*/
/*-----------------------------------*/

//keep command prompt active
void PauseCommandPrompt() { system("pause"); };


//debug print
void PrintString(string message);

/*-----------------------------------*/